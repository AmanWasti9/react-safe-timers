import React, { useState, useEffect } from 'react';
import { useSafeTimers } from './useSafeTimers'; // In your app, this would be 'react-safe-timers'

const App = () => {
    const [count, setCount] = useState(0);
    const [intervalCount, setIntervalCount] = useState(0);
    const [rafTime, setRafTime] = useState(0);
    const [status, setStatus] = useState('Idle');

    const { setSafeTimeout, setSafeInterval, setSafeRAF, clearAll } = useSafeTimers();

    const handleTimeout = () => {
        setStatus('Timeout pending (3s)...');
        setSafeTimeout(() => {
            setCount(prev => prev + 1);
            setStatus('Timeout completed!');
        }, 3000);
    };

    const handleInterval = () => {
        setStatus('Interval running...');
        setSafeInterval(() => {
            setIntervalCount(prev => prev + 1);
        }, 1000);
    };

    const handleRAF = () => {
        setStatus('RAF running...');
        const animate = (time: number) => {
            setRafTime(time);
            setSafeRAF(animate);
        };
        setSafeRAF(animate);
    };

    const handleClear = () => {
        clearAll();
        setStatus('All timers cleared!');
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
            <h1>React Safe Timers Demo</h1>
            <p>Status: <strong>{status}</strong></p>

            <div style={{ marginBottom: '20px', border: '1px solid #ccc', padding: '10px' }}>
                <h3>Timeout (3s)</h3>
                <p>Execution Count: {count}</p>
                <button onClick={handleTimeout}>Trigger Safe Timeout</button>
            </div>

            <div style={{ marginBottom: '20px', border: '1px solid #ccc', padding: '10px' }}>
                <h3>Interval (1s)</h3>
                <p>Interval Ticks: {intervalCount}</p>
                <button onClick={handleInterval}>Start Safe Interval</button>
            </div>

            <div style={{ marginBottom: '20px', border: '1px solid #ccc', padding: '10px' }}>
                <h3>RequestAnimationFrame</h3>
                <p>Last Frame Time: {rafTime.toFixed(2)}</p>
                <button onClick={handleRAF}>Start Safe RAF Loop</button>
            </div>

            <button
                onClick={handleClear}
                style={{ backgroundColor: '#ff4444', color: 'white', padding: '10px 20px', borderRadius: '5px' }}
            >
                Clear All Timers
            </button>

            <p style={{ marginTop: '20px', fontSize: '14px', color: '#666' }}>
                Note: When this component unmounts, all timers are automatically cleared.
            </p>
        </div>
    );
};

export default App;
